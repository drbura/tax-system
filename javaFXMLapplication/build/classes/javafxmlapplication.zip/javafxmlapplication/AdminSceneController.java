package javafxmlapplication;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class AdminSceneController implements Initializable {

    @FXML
    private Button registerClient;
    @FXML
    private Button logOutButton;
    @FXML
    private Button RquestBtn;
    @FXML
    private Button Tax_Amount;
    @FXML
    private Button ViewBtn;
    @FXML
    private Button ClaimBtn;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }

    @FXML
    private void registerActionHandler(ActionEvent event) throws Exception {
        utility.changeToScene(getClass(), event, "registration.fxml");
    }
     

    @FXML
    private void logOutButtonActionHandler(ActionEvent event) throws Exception {
        utility.changeToScene(getClass(), event, "FXMLDocument.fxml");
    }

//    @FXML
//    private void RquestBtnActionHandler(ActionEvent event) throws Exception {
//         utility.changeToScene(getClass(), event, "tableview.fxml");
//    }
    @FXML
    private void RquestBtnActionHandler(ActionEvent event) throws Exception{
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("TableView.fxml"));
            Parent root = loader.load();
            
            TableViewController controller = loader.getController();
            controller.displayRequestedData();

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void Tax_AmountActionHandler(ActionEvent event) throws Exception {
        utility.changeToScene(getClass(), event, "TaxAmountDialog.fxml");
    }

//    @FXML
//    private void ViewBtnActionHandler(ActionEvent event) throws Exception {
//        utility.changeToScene(getClass(), event, "tableview.fxml");
//    }
     @FXML
    private void ViewBtnActionHandler(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("TableView.fxml"));
            Parent root = loader.load();
            
            TableViewController controller = loader.getController();
            controller.displayAllData();

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void ClaimBtnActionHandler(ActionEvent event) throws Exception {
    
    }
}

//
//package javafxmlapplication;
//
//import javafx.collections.FXCollections;
//import javafx.collections.ObservableList;
//import javafx.event.ActionEvent;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Statement;
//import javafx.fxml.FXML;
//import javafx.fxml.Initializable;
//import javafx.scene.control.Button;
//import javafx.scene.control.TableColumn;
//import javafx.scene.control.TableView;
//import javafx.scene.control.cell.PropertyValueFactory;
//
//import java.net.URL;
//import java.util.ResourceBundle;
//import javafx.scene.control.TableCell;
//
//public class AdminSceneController implements Initializable {
//
//    @FXML
//    private TableView<Userdata> tableView;
//    @FXML
//    private Button requestBtn;
//
//    // ObservableList to hold table data
//    private ObservableList<Userdata> userDataList = FXCollections.observableArrayList();
//
//    @Override
//    public void initialize(URL url, ResourceBundle rb) {
//        // Initialize table columns
//        TableColumn<Userdata, String> tinColumn = new TableColumn<>("TIN Number");
//        tinColumn.setCellValueFactory(new PropertyValueFactory<>("tinNumber"));
//
//        TableColumn<Userdata, String> firstNameColumn = new TableColumn<>("First Name");
//        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
//
//        TableColumn<Userdata, String> lastNameColumn = new TableColumn<>("Last Name");
//        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
//
//        TableColumn<Userdata, String> levelColumn = new TableColumn<>("Level");
//        levelColumn.setCellValueFactory(new PropertyValueFactory<>("level"));
//
//        TableColumn<Userdata, Double> taxAmountColumn = new TableColumn<>("Tax Amount");
//        taxAmountColumn.setCellValueFactory(new PropertyValueFactory<>("taxAmount"));
//
//        TableColumn<Userdata, String> statusColumn = new TableColumn<>("Status");
//        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
//
//        // Additional column for detail buttons
//        TableColumn<Userdata, Void> detailColumn = new TableColumn<>("Details");
//        detailColumn.setCellFactory(param -> new ButtonCell());
//
//        // Add columns to the table
//        tableView.getColumns().addAll(tinColumn, firstNameColumn, lastNameColumn,
//                levelColumn, taxAmountColumn, statusColumn, detailColumn);
//
//        // Load data from the database when the scene is initialized
//        loadDataFromDatabase();
//    }
//
//    // Method to load data from the database table
//    private void loadDataFromDatabase() {
//        // Clear previous data
//        userDataList.clear();
//
//        // Perform database operations to fetch data
//        try {
//            // Establish connection to the database
//            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/taxsystemdatabase", "root", "");
//            Statement statement = connection.createStatement();
//
//            // Execute query to fetch data
//            ResultSet resultSet = statement.executeQuery("SELECT Tin_number, first_name, last_name, Level, Tax_Amount, status FROM userdatatable");
//
//            // Iterate through the result set and add data to the observable list
//            while (resultSet.next()) {
//                String tinNumber = resultSet.getString("tin_number");
//                String firstName = resultSet.getString("first_name");
//                String lastName = resultSet.getString("last_name");
//                String level = resultSet.getString("level");
//              Double  taxAmount = resultSet.getDouble("tax_amount");
//                String status = resultSet.getString("status");
//
//                userDataList.add(new Userdata(tinNumber, firstName, lastName, level, taxAmount, status));
//            }
//
//            // Close connection
//            connection.close();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//
//        // Set the table data
//        tableView.setItems(userDataList);
//    }
//
//    // Action handler for the request button
//    @FXML
//    private void requestBtnActionHandler(ActionEvent event) {
//        // Fetch data from the database again (refresh)
//        loadDataFromDatabase();
//    }
//
//    // Custom cell class for detail buttons
//    private class ButtonCell extends TableCell<Userdata, Void> {
//        private final Button detailButton;
//
//        ButtonCell() {
//            detailButton = new Button("Detail");
//            detailButton.setOnAction(event -> {
//                // Handle button click event
//                Userdata userData = getTableView().getItems().get(getIndex());
//                // Perform actions to display additional information based on userData
//                System.out.println("Detail button clicked for " + userData.getFirstName() + " " + userData.getLastName());
//            });
//        }
//
//        @Override
//        protected void updateItem(Void item, boolean empty) {
//            super.updateItem(item, empty);
//            if (empty) {
//                setGraphic(null);
//            } else {
//                setGraphic(detailButton);
//            }
//        }
//    }
//}



//package javafxmlapplication;
//
//import javafx.collections.FXCollections;
//import javafx.collections.ObservableList;
//import javafx.event.ActionEvent;
//import javafx.fxml.FXML;
//import javafx.fxml.Initializable;
//import javafx.scene.control.Button;
//import javafx.scene.control.TableColumn;
//import javafx.scene.control.TableView;
//import javafx.scene.control.cell.PropertyValueFactory;
//import javafx.scene.control.TableCell;
//
//import java.net.URL;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Statement;
//import java.util.ResourceBundle;
//
//public class AdminSceneController implements Initializable {
//
//    @FXML
//    private TableView<Userdata> tableView;
//    @FXML
//    private Button requestBtn;
//
//    // ObservableList to hold table data
//    private ObservableList<Userdata> userDataList = FXCollections.observableArrayList();
//
//    @Override
//    public void initialize(URL url, ResourceBundle rb) {
//        // Initialize table columns
//        TableColumn<Userdata, String> tinColumn = new TableColumn<>("TIN Number");
//        tinColumn.setCellValueFactory(new PropertyValueFactory<>("tinNumber"));
//
//        TableColumn<Userdata, String> firstNameColumn = new TableColumn<>("First Name");
//        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
//
//        TableColumn<Userdata, String> lastNameColumn = new TableColumn<>("Last Name");
//        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
//
//        TableColumn<Userdata, String> levelColumn = new TableColumn<>("Level");
//        levelColumn.setCellValueFactory(new PropertyValueFactory<>("level"));
//
//        TableColumn<Userdata, Double> taxAmountColumn = new TableColumn<>("Tax Amount");
//        taxAmountColumn.setCellValueFactory(new PropertyValueFactory<>("taxAmount"));
//
//        TableColumn<Userdata, String> statusColumn = new TableColumn<>("Status");
//        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
//
//        // Additional column for detail buttons
//        TableColumn<Userdata, Void> detailColumn = new TableColumn<>("Details");
//        detailColumn.setCellFactory(param -> new ButtonCell());
//
//        // Add columns to the table
//        tableView.getColumns().addAll(tinColumn, firstNameColumn, lastNameColumn,
//                levelColumn, taxAmountColumn, statusColumn, detailColumn);
//
//        // Load data from the database when the scene is initialized
//        loadDataFromDatabase();
//    }
//
//    // Method to load data from the database table
//    private void loadDataFromDatabase() {
//        // Clear previous data
//        userDataList.clear();
//
//        // Perform database operations to fetch data
//        try {
//            // Establish connection to the database
//            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/taxsystemdatabase", "root", "");
//            Statement statement = connection.createStatement();
//
//            // Execute query to fetch data
//            ResultSet resultSet = statement.executeQuery("SELECT Tin_number, first_name, last_name, Level, Tax_Amount, status FROM userdatatable");
//
//            // Iterate through the result set and add data to the observable list
//            while (resultSet.next()) {
//                String tinNumber = resultSet.getString("Tin_number");
//                String firstName = resultSet.getString("first_name");
//                String lastName = resultSet.getString("last_name");
//                String level = resultSet.getString("Level");
//                Double taxAmount = resultSet.getDouble("Tax_Amount");
//                String status = resultSet.getString("status");
//
//                userDataList.add(new Userdata(tinNumber, firstName, lastName, level, taxAmount, status));
//            }
//
//            // Close connection
//            connection.close();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//
//        // Set the table data
//        tableView.setItems(userDataList);
//    }
//
//    // Action handler for the request button
//    @FXML
//    private void requestBtnActionHandler(ActionEvent event) {
//        // Fetch data from the database again (refresh)
//        loadDataFromDatabase();
//    }
//
//    // Custom cell class for detail buttons
//    private class ButtonCell extends TableCell<Userdata, Void> {
//        private final Button detailButton;
//
//        ButtonCell() {
//            detailButton = new Button("Detail");
//            detailButton.setOnAction(event -> {
//                // Handle button click event
//                Userdata userData = getTableView().getItems().get(getIndex());
//                // Perform actions to display additional information based on userData
//                System.out.println("Detail button clicked for " + userData.getFirstName() + " " + userData.getLastName());
//            });
//        }
//
//        @Override
//        protected void updateItem(Void item, boolean empty) {
//            super.updateItem(item, empty);
//            if (empty) {
//                setGraphic(null);
//            } else {
//                setGraphic(detailButton);
//            }
//        }
//    }
//}
