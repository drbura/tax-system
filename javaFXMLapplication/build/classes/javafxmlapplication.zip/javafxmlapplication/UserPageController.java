//
//
//
//package javafxmlapplication;
//
//import javafx.event.ActionEvent;
//import javafx.fxml.FXML;
//import javafx.scene.control.Alert;
//import javafx.scene.control.Button;
//import javafx.scene.control.PasswordField;
//import javafx.scene.control.TabPane;
//import javafx.scene.control.TextField;
//import javafx.scene.control.Tab;
//import javafx.scene.image.ImageView;
//import javafx.scene.layout.AnchorPane;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//
//public class UserPageController {
//
//    @FXML
//    private TextField Tin_Number;
//
//    @FXML
//    private PasswordField password;
//
//    @FXML
//    private TextField tinNumber;
//
//    @FXML
//    private PasswordField firstName;
//
//    @FXML
//    private ImageView IMG_url;
//
//    @FXML
//    private TextField lastName;
//
//    @FXML
//    private TextField PHONE;
//
//    @FXML
//    private Button sendButton;
//
//    @FXML
//    private Button bankRecipt;
//
//    @FXML
//    private TextField phoneNumber;
//
//    @FXML
//    private PasswordField oldPassword;
//
//    @FXML
//    private Button logout;
//
//    @FXML
//    private Tab phone;
//
//    @FXML
//    private Button okPassword;
//
//    @FXML
//    private TabPane tabPane;
//
//    @FXML
//    private void initialize() {
//        // Add a listener to switch tabs and add the "Ok" button dynamically
//        tabPane.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
//            if (newValue != null && newValue.getText().equals("Tax Amount")) {
//                addButtonToTaxAmountTab();
//            }
//        });
//
//        // Add the "Ok" button to the "Tax Amount" tab immediately
//        addButtonToTaxAmountTab();
//    }
//
//    private void addButtonToTaxAmountTab() {
//        // Create the "Ok" button
//        Button okButton = new Button("Ok");
//        okButton.setOnAction(event -> {
//            try {
//                String tin = Tin_Number.getText();
//                if (!tin.isEmpty()) {
//                    double amount = getAmountForTIN(tin);
//                    // Show the amount in a popup dialog
//                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
//                    alert.setTitle("Tax Amount");
//                    alert.setHeaderText(null);
//                    alert.setContentText(" your Amount of tax is "  + amount);
//                    alert.showAndWait();
//                } else {
//                    // Show an error message if TIN number is empty
//                    Alert alert = new Alert(Alert.AlertType.ERROR);
//                    alert.setTitle("Error");
//                    alert.setHeaderText(null);
//                    alert.setContentText("TIN number is empty");
//                    alert.showAndWait();
//                }
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        });
//
//        // Add the button to the layout of the "Tax Amount" tab
//        AnchorPane.setLeftAnchor(okButton, 90.0);
//        AnchorPane.setTopAnchor(okButton, 130.0);
//        ((AnchorPane) tabPane.getSelectionModel().getSelectedItem().getContent()).getChildren().add(okButton);
//    }
//
//    private double getAmountForTIN(String tin) throws Exception {
//        // Perform database operation to retrieve the amount for the given TIN number
//        // Replace this with your actual database code
//        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/taxsystemdatabase", "root", "");
//             PreparedStatement stmt = conn.prepareStatement("SELECT Tax_Amount FROM userdatatable WHERE Tin_Number = ?")) {
//            stmt.setString(1, tin);
//            try (ResultSet rs = stmt.executeQuery()) {
//                if (rs.next()) {
//                    return rs.getDouble("Tax_Amount");
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace(); // Print the stack trace of the exception
//            throw e; // Rethrow the exception to propagate it to the caller
//        }
//        return 0.0; // Return a default value if no amount is found
//    }
//
//    @FXML
//    private void sendButtonActionHandler(ActionEvent event) throws Exception {
//        // Handle sendButton action here
//    }
//
//    @FXML
//    private void bankReciptActionHandler(ActionEvent event) throws Exception {
//        // Handle bankRecipt action here
//    }
//
//    @FXML
//    private void logOutActionHandler(ActionEvent event) throws Exception {
//        utility.changeToScene(getClass(), event, "FXMLDocument.fxml");
//        // Handle logout action here
//    }
//}
//

//
//package javafxmlapplication;
//
//import javafx.event.ActionEvent;
//import javafx.fxml.FXML;
//import javafx.scene.control.Alert;
//import javafx.scene.control.Button;
//import javafx.scene.control.PasswordField;
//import javafx.scene.control.TabPane;
//import javafx.scene.control.TextField;
//import javafx.scene.control.Tab;
//import javafx.scene.image.Image;
//import javafx.scene.image.ImageView;
//import javafx.scene.layout.AnchorPane;
//import javafx.stage.FileChooser;
//
//import java.io.File;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//
//public class UserPageController {
//
//    @FXML
//    private TextField Tin_Number;
//
//    @FXML
//    private PasswordField password;
//
//    @FXML
//    private TextField tinNumber;
//
//    @FXML
//    private TextField firstName;
//
//    @FXML
//    private ImageView IMG_url;
//
//    @FXML
//    private TextField lastName;
//
//    @FXML
//    private TextField PHONE;
//
//    @FXML
//    private Button sendButton;
//
//    @FXML
//    private Button bankRecipt;
//
//    @FXML
//    private TextField phoneNumber;
//
//    @FXML
//    private PasswordField oldPassword;
//
//    @FXML
//    private Button logout;
//
//    @FXML
//    private Tab phone;
//
//    @FXML
//    private TabPane tabPane;
//
//    private File selectedFile;
//
//    private void initialize() {
//        // Add a listener to switch tabs and add the "Ok" button dynamically
//        tabPane.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
//            if (newValue != null && newValue.getText().equals("Tax Amount")) {
//                addButtonToTaxAmountTab();
//            }
//        });
//
//        // Add the "Ok" button to the "Tax Amount" tab immediately
//        addButtonToTaxAmountTab();
//        
//        // Set the action handler for the bankRecipt button
//        bankRecipt.setOnAction(this::bankReciptActionHandler);
//        
//        // Set the action handler for the send button
//        sendButton.setOnAction(this::sendButtonActionHandler);
//    }
//
//    private void addButtonToTaxAmountTab() {
//        // Create the "Ok" button
//        Button okButton = new Button("Ok");
//        okButton.setOnAction(event -> {
//            try {
//                String tin = Tin_Number.getText();
//                if (!tin.isEmpty()) {
//                    double amount = getAmountForTIN(tin);
//                    // Show the amount in a popup dialog
//                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
//                    alert.setTitle("Tax Amount");
//                    alert.setHeaderText(null);
//                    alert.setContentText("Your amount of tax is " + amount);
//                    alert.showAndWait();
//                } else {
//                    // Show an error message if TIN number is empty
//                    Alert alert = new Alert(Alert.AlertType.ERROR);
//                    alert.setTitle("Error");
//                    alert.setHeaderText(null);
//                    alert.setContentText("TIN number is empty");
//                    alert.showAndWait();
//                }
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        });
//
//        // Add the button to the layout of the "Tax Amount" tab
//        AnchorPane.setLeftAnchor(okButton, 90.0);
//        AnchorPane.setTopAnchor(okButton, 130.0);
//        ((AnchorPane) tabPane.getSelectionModel().getSelectedItem().getContent()).getChildren().add(okButton);
//    }
//
//    @FXML
//    private void bankReciptActionHandler(ActionEvent event) {
//        FileChooser fileChooser = new FileChooser();
//        fileChooser.getExtensionFilters().addAll(
//            new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
//        );
//        selectedFile = fileChooser.showOpenDialog(bankRecipt.getScene().getWindow());
//        if (selectedFile != null) {
//            Image image = new Image(selectedFile.toURI().toString());
//            IMG_url.setImage(image);
//            System.out.println("Image selected: " + selectedFile.getAbsolutePath());
//        }
//    }
//
//    @FXML
//    private void sendButtonActionHandler(ActionEvent event) {
//        try {
//            String tin = tinNumber.getText();
//            String fName = firstName.getText();
//            String lName = lastName.getText();
//            String phone = PHONE.getText();
//            String imagePath = selectedFile != null ? selectedFile.toURI().toString() : null; // Get the image URL
//
////            System.out.println("TIN: " + tin);
////            System.out.println("First Name: " + fName);
////            System.out.println("Last Name: " + lName);
////            System.out.println("Phone: " + phone);
////            System.out.println("Image Path: " + imagePath);
//
//            if (!tin.isEmpty() && !fName.isEmpty() && !lName.isEmpty() && !phone.isEmpty() && imagePath != null) {
//                if (checkTINExists(tin)) {
//                    insertIntoRequestTable(tin, fName, lName, phone, imagePath);
//                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
//                    alert.setTitle("Success");
//                    alert.setHeaderText(null);
//                    alert.setContentText("Request submitted successfully.");
//                    alert.showAndWait();
//                } else {
//                    Alert alert = new Alert(Alert.AlertType.ERROR);
//                    alert.setTitle("Error");
//                    alert.setHeaderText(null);
//                    alert.setContentText("TIN number does not exist.");
//                    alert.showAndWait();
//                }
//            } else {
//                System.out.println("Validation failed:");
//                if (tin.isEmpty()) System.out.println("TIN is empty");
//                if (fName.isEmpty()) System.out.println("First Name is empty");
//                if (lName.isEmpty()) System.out.println("Last Name is empty");
//                if (phone.isEmpty()) System.out.println("Phone is empty");
//                if (imagePath == null) System.out.println("Image Path is null");
//                
//                Alert alert = new Alert(Alert.AlertType.ERROR);
//                alert.setTitle("Error");
//                alert.setHeaderText(null);
//                alert.setContentText("Please fill all fields.");
//                alert.showAndWait();
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//    private boolean checkTINExists(String tin) throws Exception {
//        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/taxsystemdatabase", "root", "");
//             PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) FROM userdatatable WHERE Tin_Number = ?")) {
//            stmt.setString(1, tin);
//            try (ResultSet rs = stmt.executeQuery()) {
//                if (rs.next()) {
//                    return rs.getInt(1) > 0;
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace(); // Print the stack trace of the exception
//            throw e; // Rethrow the exception to propagate it to the caller
//        }
//        return false;
//    }
//
//    private void insertIntoRequestTable(String tin, String fName, String lName, String phone, String imagePath) throws Exception {
//        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/taxsystemdatabase", "root", "");
//             PreparedStatement stmt = conn.prepareStatement("INSERT INTO requestable (tinNumber, firstName, lastName, PHONE, IMG_URL) VALUES (?, ?, ?, ?, ?)")) {
//            stmt.setString(1, tin);
//            stmt.setString(2, fName);
//            stmt.setString(3, lName);
//            stmt.setString(4, phone);
//            stmt.setString(5, imagePath);
//            stmt.executeUpdate();
//        } catch (Exception e) {
//            e.printStackTrace(); // Print the stack trace of the exception
//            throw e; // Rethrow the exception to propagate it to the caller
//        }
//    }
//
//    private double getAmountForTIN(String tin) throws Exception {
//        // Perform database operation to retrieve the amount for the given TIN number
//        // Replace this with your actual database code
//        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/taxsystemdatabase", "root", "");
//             PreparedStatement stmt = conn.prepareStatement("SELECT Tax_Amount FROM userdatatable WHERE Tin_Number = ?")) {
//            stmt.setString(1, tin);
//            try (ResultSet rs = stmt.executeQuery()) {
//                if (rs.next()) {
//                    return rs.getDouble("Tax_Amount");
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace(); // Print the stack trace of the exception
//            throw e; // Rethrow the exception to propagate it to the caller
//        }
//        return 0.0; // Return a default value if no amount is found
//    }
//
//    @FXML
//    private void logOutActionHandler(ActionEvent event) throws Exception {
//        utility.changeToScene(getClass(), event, "FXMLDocument.fxml");
//        // Handle logout action here
//    }
//}


//
//package javafxmlapplication;
//
//import javafx.event.ActionEvent;
//import javafx.fxml.FXML;
//import javafx.scene.control.Alert;
//import javafx.scene.control.Button;
//import javafx.scene.control.PasswordField;
//import javafx.scene.control.TabPane;
//import javafx.scene.control.TextField;
//import javafx.scene.control.Tab;
//import javafx.scene.image.Image;
//import javafx.scene.image.ImageView;
//import javafx.scene.layout.AnchorPane;
//import javafx.stage.FileChooser;
//
//import java.io.File;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//
//public class UserPageController {
//
//    @FXML
//    private TextField Tin_Number;
//
//    @FXML
//    private PasswordField password;
//
//    @FXML
//    private TextField tinNumber;
//
//    @FXML
//    private TextField firstName;
//
//    @FXML
//    private ImageView IMG_url;
//
//    @FXML
//    private TextField lastName;
//
//    @FXML
//    private TextField PHONE;
//
//    @FXML
//    private Button sendButton;
//
//    @FXML
//    private Button bankRecipt;
//
//    @FXML
//    private TextField phoneNumber;
//
//    @FXML
//    private PasswordField oldPassword;
//
//    @FXML
//    private Button logout;
//
//    @FXML
//    private Tab phone;
//
//    @FXML
//    private TabPane tabPane;
//
//    private File selectedFile;
//
//    private void initialize() {
//        // Add a listener to switch tabs and add the "Ok" button dynamically
//        tabPane.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
//            if (newValue != null && newValue.getText().equals("Tax Amount")) {
//                addButtonToTaxAmountTab();
//            }
//        });
//
//        // Add the "Ok" button to the "Tax Amount" tab immediately
//        addButtonToTaxAmountTab();
//        
//        // Set the action handler for the bankRecipt button
//        bankRecipt.setOnAction(this::bankReciptActionHandler);
//        
//        // Set the action handler for the send button
//        sendButton.setOnAction(this::sendButtonActionHandler);
//    }
//
//    private void addButtonToTaxAmountTab() {
//        // Create the "Ok" button
//        Button okButton = new Button("Ok");
//        okButton.setOnAction(event -> {
//            try {
//                String tin = Tin_Number.getText();
//                if (!tin.isEmpty()) {
//                    double amount = getAmountForTIN(tin);
//                    // Show the amount in a popup dialog
//                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
//                    alert.setTitle("Tax Amount");
//                    alert.setHeaderText(null);
//                    alert.setContentText("Your amount of tax is " + amount);
//                    alert.showAndWait();
//                } else {
//                    // Show an error message if TIN number is empty
//                    Alert alert = new Alert(Alert.AlertType.ERROR);
//                    alert.setTitle("Error");
//                    alert.setHeaderText(null);
//                    alert.setContentText("TIN number is empty");
//                    alert.showAndWait();
//                }
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        });
//
//        // Add the button to the layout of the "Tax Amount" tab
//        AnchorPane.setLeftAnchor(okButton, 90.0);
//        AnchorPane.setTopAnchor(okButton, 130.0);
//        ((AnchorPane) tabPane.getSelectionModel().getSelectedItem().getContent()).getChildren().add(okButton);
//    }
//
//    @FXML
//    private void bankReciptActionHandler(ActionEvent event) {
//        FileChooser fileChooser = new FileChooser();
//        fileChooser.getExtensionFilters().addAll(
//            new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
//        );
//        selectedFile = fileChooser.showOpenDialog(bankRecipt.getScene().getWindow());
//        if (selectedFile != null) {
//            Image image = new Image(selectedFile.toURI().toString());
//            IMG_url.setImage(image);
//            System.out.println("Image selected: " + selectedFile.getAbsolutePath());
//        }
//    }
//
//    @FXML
//    private void sendButtonActionHandler(ActionEvent event) {
//        try {
//            String tin = tinNumber.getText();
//            String fName = firstName.getText();
//            String lName = lastName.getText();
//            String phone = PHONE.getText();
//            String imagePath = selectedFile != null ? selectedFile.toURI().toString() : null; // Get the image URL
//
//            if (!tin.isEmpty() && !fName.isEmpty() && !lName.isEmpty() && !phone.isEmpty() && imagePath != null) {
//                if (checkTINExists(tin)) {
//                    insertIntoRequestTable(tin, fName, lName, phone, imagePath);
//                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
//                    alert.setTitle("Success");
//                    alert.setHeaderText(null);
//                    alert.setContentText("Request submitted successfully.");
//                    alert.showAndWait();
//                } else {
//                    Alert alert = new Alert(Alert.AlertType.ERROR);
//                    alert.setTitle("Error");
//                    alert.setHeaderText(null);
//                    alert.setContentText("TIN number does not exist.");
//                    alert.showAndWait();
//                }
//            } else {
//                System.out.println("Validation failed:");
//                if (tin.isEmpty()) System.out.println("TIN is empty");
//                if (fName.isEmpty()) System.out.println("First Name is empty");
//                if (lName.isEmpty()) System.out.println("Last Name is empty");
//                if (phone.isEmpty()) System.out.println("Phone is empty");
//                if (imagePath == null) System.out.println("Image Path is null");
//                
//                Alert alert = new Alert(Alert.AlertType.ERROR);
//                alert.setTitle("Error");
//                alert.setHeaderText(null);
//                alert.setContentText("Please fill all fields.");
//                alert.showAndWait();
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//    private boolean checkTINExists(String tin) throws Exception {
//        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/taxsystemdatabase", "root", "");
//             PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) FROM userdatatable WHERE Tin_Number = ?")) {
//            stmt.setString(1, tin);
//            try (ResultSet rs = stmt.executeQuery()) {
//                if (rs.next()) {
//                    return rs.getInt(1) > 0;
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace(); // Print the stack trace of the exception
//            throw e; // Rethrow the exception to propagate it to the caller
//        }
//        return false;
//    }
//
//    private void insertIntoRequestTable(String tin, String fName, String lName, String phone, String imagePath) throws Exception {
//        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/taxsystemdatabase", "root", "")) {
//            // Start a transaction
//            conn.setAutoCommit(false);
//
//            // Insert into requestable table
//            try (PreparedStatement stmt = conn.prepareStatement("INSERT INTO requestable (tinNumber, firstName, lastName, PHONE, IMG_URL) VALUES (?, ?, ?, ?, ?)")) {
//                stmt.setString(1, tin);
//                stmt.setString(2, fName);
//                stmt.setString(3, lName);
//                stmt.setString(4, phone);
//                stmt.setString(5, imagePath);
//                stmt.executeUpdate();
//            }
//
//            // Update status column in userdatatable table
//            try (PreparedStatement stmt = conn.prepareStatement("UPDATE userdatatable SET status = 'requested' WHERE Tin_Number = ?")) {
//                stmt.setString(1, tin);
//                stmt.executeUpdate();
//            }
//
//            // Commit the transaction
//            conn.commit();
//        } catch (Exception e) {
//            e.printStackTrace(); // Print the stack trace of the exception
//            throw e; // Rethrow the exception to propagate it to the caller
//        }
//    }
//
//    private double getAmountForTIN(String tin) throws Exception {
//        // Perform database operation to retrieve the amount for the given TIN number
//        // Replace this with your actual database code
//        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/taxsystemdatabase", "root", "");
//             PreparedStatement stmt = conn.prepareStatement("SELECT Tax_Amount FROM userdatatable WHERE Tin_Number = ?")) {
//            stmt.setString(1, tin);
//            try (ResultSet rs = stmt.executeQuery()) {
//                if (rs.next()) {
//                    return rs.getDouble("Tax_Amount");
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace(); // Print the stack trace of the exception
//            throw e; // Rethrow the exception to propagate it to the caller
//        }
//        return 0.0; // Return a default value if no amount is found
//    }
//
//    @FXML
//    private void logOutActionHandler(ActionEvent event) throws Exception {
//        utility.changeToScene(getClass(), event, "FXMLDocument.fxml");
//        // Handle logout action here
//    }
//}

//
//
//package javafxmlapplication;
//
//import javafx.event.ActionEvent;
//import javafx.fxml.FXML;
//import javafx.scene.control.Alert;
//import javafx.scene.control.Button;
//import javafx.scene.control.PasswordField;
//import javafx.scene.control.TabPane;
//import javafx.scene.control.TextField;
//import javafx.scene.control.Tab;
//import javafx.scene.image.Image;
//import javafx.scene.image.ImageView;
//import javafx.scene.layout.AnchorPane;
//import javafx.stage.FileChooser;
//
//import java.io.File;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//
//public class UserPageController {
//
//    @FXML
//    private TextField Tin_Number;
//
//    @FXML
//    private PasswordField password;
//
//    @FXML
//    private TextField tinNumber;
//
//    @FXML
//    private TextField firstName;
//
//    @FXML
//    private ImageView IMG_url;
//
//    @FXML
//    private TextField lastName;
//
//    @FXML
//    private TextField PHONE;
//
//    @FXML
//    private Button sendButton;
//
//    @FXML
//    private Button bankRecipt;
//
//    @FXML
//    private TextField phoneNumber;
//
//    @FXML
//    private PasswordField oldPassword;
//
//    @FXML
//    private Button logout;
//
//    @FXML
//    private Tab phone;
//
//    @FXML
//    private TabPane tabPane;
//
//    private File selectedFile;
//
//    @FXML
//    private void initialize() {
//        // Add a listener to switch tabs and add the "Ok" button dynamically
//        tabPane.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
//            if (newValue != null && newValue.getText().equals("Tax Amount")) {
//                addButtonToTaxAmountTab();
//            }
//        });
//
//        // Set the action handler for the bankRecipt button
//        bankRecipt.setOnAction(this::bankReciptActionHandler);
//        
//        // Set the action handler for the send button
//        sendButton.setOnAction(this::sendButtonActionHandler);
//    }
//
//    private void addButtonToTaxAmountTab() {
//        // Check if the tab exists
//        Tab taxAmountTab = tabPane.getTabs().stream()
//                .filter(tab -> "Tax Amount".equals(tab.getText()))
//                .findFirst()
//                .orElse(null);
//
//        if (taxAmountTab != null && taxAmountTab.getContent() instanceof AnchorPane) {
//            AnchorPane anchorPane = (AnchorPane) taxAmountTab.getContent();
//            
//            // Remove any existing "Ok" button to avoid duplicates
//            anchorPane.getChildren().removeIf(node -> node instanceof Button && "Ok".equals(((Button) node).getText()));
//
//            // Create the "Ok" button
//            Button okButton = new Button("Ok");
//            okButton.setOnAction(event -> {
//                try {
//                    String tin = Tin_Number.getText();
//                    if (!tin.isEmpty()) {
//                        double amount = getAmountForTIN(tin);
//                        // Show the amount in a popup dialog
//                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
//                        alert.setTitle("Tax Amount");
//                        alert.setHeaderText(null);
//                        alert.setContentText("Your amount of tax is " + amount);
//                        alert.showAndWait();
//                    } else {
//                        // Show an error message if TIN number is empty
//                        Alert alert = new Alert(Alert.AlertType.ERROR);
//                        alert.setTitle("Error");
//                        alert.setHeaderText(null);
//                        alert.setContentText("TIN number is empty");
//                        alert.showAndWait();
//                    }
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            });
//
//            // Add the button to the layout of the "Tax Amount" tab
//            AnchorPane.setLeftAnchor(okButton, 90.0);
//            AnchorPane.setTopAnchor(okButton, 130.0);
//            anchorPane.getChildren().add(okButton);
//        }
//    }
//
//    @FXML
//    private void bankReciptActionHandler(ActionEvent event) {
//        FileChooser fileChooser = new FileChooser();
//        fileChooser.getExtensionFilters().addAll(
//            new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
//        );
//        selectedFile = fileChooser.showOpenDialog(bankRecipt.getScene().getWindow());
//        if (selectedFile != null) {
//            Image image = new Image(selectedFile.toURI().toString());
//            IMG_url.setImage(image);
//            System.out.println("Image selected: " + selectedFile.getAbsolutePath());
//        }
//    }
//
//    @FXML
//    private void sendButtonActionHandler(ActionEvent event) {
//        try {
//            String tin = tinNumber.getText();
//            String fName = firstName.getText();
//            String lName = lastName.getText();
//            String phone = PHONE.getText();
//            String imagePath = selectedFile != null ? selectedFile.toURI().toString() : null; // Get the image URL
//
//            if (!tin.isEmpty() && !fName.isEmpty() && !lName.isEmpty() && !phone.isEmpty() && imagePath != null) {
//                if (checkTINExists(tin)) {
//                    insertIntoRequestTable(tin, fName, lName, phone, imagePath);
//                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
//                    alert.setTitle("Success");
//                    alert.setHeaderText(null);
//                    alert.setContentText("Request submitted successfully.");
//                    alert.showAndWait();
//                } else {
//                    Alert alert = new Alert(Alert.AlertType.ERROR);
//                    alert.setTitle("Error");
//                    alert.setHeaderText(null);
//                    alert.setContentText("TIN number does not exist.");
//                    alert.showAndWait();
//                }
//            } else {
//                System.out.println("Validation failed:");
//                if (tin.isEmpty()) System.out.println("TIN is empty");
//                if (fName.isEmpty()) System.out.println("First Name is empty");
//                if (lName.isEmpty()) System.out.println("Last Name is empty");
//                if (phone.isEmpty()) System.out.println("Phone is empty");
//                if (imagePath == null) System.out.println("Image Path is null");
//                
//                Alert alert = new Alert(Alert.AlertType.ERROR);
//                alert.setTitle("Error");
//                alert.setHeaderText(null);
//                alert.setContentText("Please fill all fields.");
//                alert.showAndWait();
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//    private boolean checkTINExists(String tin) throws Exception {
//        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/taxsystemdatabase", "root", "");
//             PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) FROM userdatatable WHERE Tin_Number = ?")) {
//            stmt.setString(1, tin);
//            try (ResultSet rs = stmt.executeQuery()) {
//                if (rs.next()) {
//                    return rs.getInt(1) > 0;
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace(); // Print the stack trace of the exception
//            throw e; // Rethrow the exception to propagate it to the caller
//        }
//        return false;
//    }
//
//    private void insertIntoRequestTable(String tin, String fName, String lName, String phone, String imagePath) throws Exception {
//        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/taxsystemdatabase", "root", "")) {
//            // Start a transaction
//            conn.setAutoCommit(false);
//
//            // Insert into requestable table
//            try (PreparedStatement stmt = conn.prepareStatement("INSERT INTO requestable (tinNumber, firstName, lastName, PHONE, IMG_URL) VALUES (?, ?, ?, ?, ?)")) {
//                stmt.setString(1, tin);
//                stmt.setString(2, fName);
//                stmt.setString(3, lName);
//                stmt.setString(4, phone);
//                stmt.setString(5, imagePath);
//                stmt.executeUpdate();
//            }
//
//            // Update status column in userdatatable table
//            try (PreparedStatement stmt = conn.prepareStatement("UPDATE userdatatable SET status = 'requested' WHERE Tin_Number = ?")) {
//                stmt.setString(1, tin);
//                stmt.executeUpdate();
//            }
//
//            // Commit the transaction
//            conn.commit();
//        } catch (Exception e) {
//            e.printStackTrace(); // Print the stack trace of the exception
//            throw e; // Rethrow the exception to propagate it to the caller
//        }
//    }
//
//    private double getAmountForTIN(String tin) throws Exception {
//        // Perform database operation to retrieve the amount for the given TIN number
//        // Replace this with your actual database code
//        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/taxsystemdatabase", "root", "");
//             PreparedStatement stmt = conn.prepareStatement("SELECT Tax_Amount FROM userdatatable WHERE Tin_Number = ?")) {
//            stmt.setString(1, tin);
//            try (ResultSet rs = stmt.executeQuery()) {
//                if (rs.next()) {
//                    return rs.getDouble("Tax_Amount");
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace(); // Print the stack trace of the exception
//            throw e; // Rethrow the exception to propagate it to the caller
//        }
//        return 0.0; // Return a default value if no amount is found
//    }
//
//    @FXML
//    private void logOutActionHandler(ActionEvent event) throws Exception {
//        utility.changeToScene(getClass(), event, "FXMLDocument.fxml");
//        // Handle logout action here
//    }
//}


package javafxmlapplication;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.control.Tab;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserPageController {

    @FXML
    private TextField Tin_Number;

    @FXML
    private PasswordField password;

    @FXML
    private TextField tinNumber;

    @FXML
    private TextField firstName;

    @FXML
    private ImageView IMG_url;

    @FXML
    private TextField lastName;

    @FXML
    private TextField PHONE;

    @FXML
    private Button sendButton;

    @FXML
    private Button bankRecipt;

    @FXML
    private TextField phoneNumber;

    @FXML
    private PasswordField oldPassword;

    @FXML
    private Button logout;

    @FXML
    private Tab phone;

    @FXML
    private TabPane tabPane;

    private File selectedFile;

//    private void initialize() {
//        // Add a listener to switch tabs and add the "Ok" button dynamically
//        tabPane.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
//            if (newValue != null && newValue.getText().equals("Tax Amount")) {
//                addButtonToTaxAmountTab();
//            }
//        });
//
//        // Set the action handler for the bankRecipt button
//        bankRecipt.setOnAction(this::bankReciptActionHandler);
//        
//        // Set the action handler for the send button
//        sendButton.setOnAction(this::sendButtonActionHandler);
//
//        // Add the "Ok" button to the "Tax Amount" tab immediately
//        addButtonToTaxAmountTab();
//    }
    
    @FXML
public void initialize() {
    // Add a listener to switch tabs and add the "Ok" button dynamically
    tabPane.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
        if (newValue != null && newValue.getText().equals("Tax Amount")) {
            addButtonToTaxAmountTab();
        }
    });

    // Set the action handler for the bankRecipt button
    bankRecipt.setOnAction(this::bankReciptActionHandler);
    
    // Set the action handler for the send button
    sendButton.setOnAction(this::sendButtonActionHandler);

    // Add the "Ok" button to the "Tax Amount" tab immediately
    addButtonToTaxAmountTab();
}


    private void addButtonToTaxAmountTab() {
        // Check if the tab exists
        Tab taxAmountTab = tabPane.getTabs().stream()
                .filter(tab -> "Tax Amount".equals(tab.getText()))
                .findFirst()
                .orElse(null);

        if (taxAmountTab != null && taxAmountTab.getContent() instanceof AnchorPane) {
            AnchorPane anchorPane = (AnchorPane) taxAmountTab.getContent();
            
            // Remove any existing "Ok" button to avoid duplicates
            anchorPane.getChildren().removeIf(node -> node instanceof Button && "Ok".equals(((Button) node).getText()));

            // Create the "Ok" button
            Button okButton = new Button("Ok");
            okButton.setOnAction(event -> {
                try {
                    String tin = Tin_Number.getText();
                    if (!tin.isEmpty()) {
                        double amount = getAmountForTIN(tin);
                        // Show the amount in a popup dialog
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Tax Amount");
                        alert.setHeaderText(null);
                        alert.setContentText("Your amount of tax is " + amount);
                        alert.showAndWait();
                    } else {
                        // Show an error message if TIN number is empty
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Error");
                        alert.setHeaderText(null);
                        alert.setContentText("TIN number is empty");
                        alert.showAndWait();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });

            // Add the button to the layout of the "Tax Amount" tab
            AnchorPane.setLeftAnchor(okButton, 90.0);
            AnchorPane.setTopAnchor(okButton, 130.0);
            anchorPane.getChildren().add(okButton);
        }
    }

    @FXML
    private void bankReciptActionHandler(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
        );
        selectedFile = fileChooser.showOpenDialog(bankRecipt.getScene().getWindow());
        if (selectedFile != null) {
            Image image = new Image(selectedFile.toURI().toString());
            IMG_url.setImage(image);
            System.out.println("Image selected: " + selectedFile.getAbsolutePath());
        }
    }

    @FXML
    private void sendButtonActionHandler(ActionEvent event) {
        try {
            String tin = tinNumber.getText();
            String fName = firstName.getText();
            String lName = lastName.getText();
            String phone = PHONE.getText();
            String imagePath = selectedFile != null ? selectedFile.toURI().toString() : null; // Get the image URL

            if (!tin.isEmpty() && !fName.isEmpty() && !lName.isEmpty() && !phone.isEmpty() && imagePath != null) {
                if (checkTINExists(tin)) {
                    insertIntoRequestTable(tin, fName, lName, phone, imagePath);
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Success");
                    alert.setHeaderText(null);
                    alert.setContentText("Request submitted successfully.");
                    alert.showAndWait();
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText(null);
                    alert.setContentText("TIN number does not exist.");
                    alert.showAndWait();
                }
            } else {
                System.out.println("Validation failed:");
                if (tin.isEmpty()) System.out.println("TIN is empty");
                if (fName.isEmpty()) System.out.println("First Name is empty");
                if (lName.isEmpty()) System.out.println("Last Name is empty");
                if (phone.isEmpty()) System.out.println("Phone is empty");
                if (imagePath == null) System.out.println("Image Path is null");
                
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("Please fill all fields.");
                alert.showAndWait();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean checkTINExists(String tin) throws Exception {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/taxsystemdatabase", "root", "");
             PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) FROM userdatatable WHERE Tin_Number = ?")) {
            stmt.setString(1, tin);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (Exception e) {
            e.printStackTrace(); // Print the stack trace of the exception
            throw e; // Rethrow the exception to propagate it to the caller
        }
        return false;
    }

    private void insertIntoRequestTable(String tin, String fName, String lName, String phone, String imagePath) throws Exception {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/taxsystemdatabase", "root", "")) {
            // Start a transaction
            conn.setAutoCommit(false);

            // Insert into requestable table
            try (PreparedStatement stmt = conn.prepareStatement("INSERT INTO requestable (tinNumber, firstName, lastName, PHONE, IMG_URL) VALUES (?, ?, ?, ?, ?)")) {
                stmt.setString(1, tin);
                stmt.setString(2, fName);
                stmt.setString(3, lName);
                stmt.setString(4, phone);
                stmt.setString(5, imagePath);
                stmt.executeUpdate();
            }

            // Update status column in userdatatable table
            try (PreparedStatement stmt = conn.prepareStatement("UPDATE userdatatable SET status = 'requested' WHERE Tin_Number = ?")) {
                stmt.setString(1, tin);
                stmt.executeUpdate();
            }

            // Commit the transaction
            conn.commit();
        } catch (Exception e) {
            e.printStackTrace(); // Print the stack trace of the exception
            throw e; // Rethrow the exception to propagate it to the caller
        }
    }

    private double getAmountForTIN(String tin) throws Exception {
        // Perform database operation to retrieve the amount for the given TIN number
        // Replace this with your actual database code
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/taxsystemdatabase", "root", "");
             PreparedStatement stmt = conn.prepareStatement("SELECT Tax_Amount FROM userdatatable WHERE Tin_Number = ?")) {
            stmt.setString(1, tin);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble("Tax_Amount");
                }
            }
        } catch (Exception e) {
            e.printStackTrace(); // Print the stack trace of the exception
            throw e; // Rethrow the exception to propagate it to the caller
        }
        return 0.0; // Return a default value if no amount is found
    }

    @FXML
    private void logOutActionHandler(ActionEvent event) throws Exception {
        utility.changeToScene(getClass(), event, "FXMLDocument.fxml");
        // Handle logout action here
    }
}
