
//
//package javafxmlapplication;
//public class user {
//    private String First_name;
//    private String Last_name;
//    private String Tin_number;
//    private String Level;
//    private String phone;
//    private String kebele;
//    private Double Tax_Amount;
//    private String status;
//
//    // Constructor
//    public user(String tinNumber, String firstName, String lastName, String level, Double taxAmount, String phone, String status) {
//        this.Tin_number = tinNumber;
//        this.First_name = firstName;
//        this.Last_name = lastName;
//        this.Level = level;
//        this.phone = phone;
//        this.kebele = "";
//        this.Tax_Amount = taxAmount;
//        this.status = status;
//    }
//
//    // Getters
//    public String getFirst_name() {
//        return First_name;
//    }
//
//    public String getLast_name(){
//        
//        return Last_name;
//    }
//
//    public String getTin_number() {
//        return Tin_number;
//    }
//
//    public String getLevel() {
//        return Level;
//    }
//
//    public String getPhone() {
//        return phone;
//    }
//
//    public String getKebele() {
//        return kebele;
//    }
//
//    public Double getTax_Amount() {
//        return Tax_Amount;
//    }
//
//    public String getStatus() {
//        return status;
//    }
//}



package javafxmlapplication;

public class user {
    private String tinNumber;
    private String firstName;
    private String lastName;
    private String level;
    private Double taxAmount;
    private String phone;
    private String status;
    private String imageURL; // New attribute for image URL

    public user(String tinNumber, String firstName, String lastName, String level, Double taxAmount, String phone, String status, String imageURL) {
        this.tinNumber = tinNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.level = level;
        this.taxAmount = taxAmount;
        this.phone = phone;
        this.status = status;
        this.imageURL = imageURL;
    }

    // Getters and setters
    public String getTin_number() {
        return tinNumber;
    }

    public void setTin_number(String tinNumber) {
        this.tinNumber = tinNumber;
    }

    public String getFirst_name() {
        return firstName;
    }

    public void setFirst_name(String firstName) {
        this.firstName = firstName;
    }

    public String getLast_name() {
        return lastName;
    }

    public void setLast_name(String lastName) {
        this.lastName = lastName;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public Double getTax_Amount() {
        return taxAmount;
    }

    public void setTax_Amount(Double taxAmount) {
        this.taxAmount = taxAmount;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getIMG_url() {
        return imageURL;
    }

    public void setIMG_url(String imageURL) {
        this.imageURL = imageURL;
    }
}

